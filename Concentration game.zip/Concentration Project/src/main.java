import tester.Tester;

//represents Examples:
class Main {

  // main:
  // *****************************************************************
  // all you need to edit is the width:
  int width = 800; // screen is built to be a square no matter what
  Concentration worldUsed = new Concentration(width);

  void testBigBang(Tester t) {
    worldUsed.bigBang(worldUsed.sceneWidth, worldUsed.sceneWidth, 1.0);
  }

  // ****************************************************************

}
