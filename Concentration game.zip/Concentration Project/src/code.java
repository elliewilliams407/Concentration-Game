import java.util.ArrayList;
import java.util.Arrays;

import javalib.impworld.*;
import java.awt.Color;
import javalib.worldimages.*;
import java.util.Random;

/*overview: Concentration 
 * - is a card game
 * - all cards are face down
 * - each turn has two cards be flipped over
 * - only ONE player
 * 
 * objective of game:
 * find pairs of matching cards
 */


//represents a single card 
class Card {
  String rank; // options: "Ace", 1-10, "Jack", "Queen", "King"
  String suit; // options: "♣" "♦" "♥" "♠"
  int value; // options: 1-13
  boolean isFaceUp = false; // default is false
  boolean removed = false; // tracks if card is removed (found)

  // main constructor
  Card(String rank, String suit, int value) {
    this.rank = rank;
    this.suit = suit;
    this.value = value;
  }
  
  /*Template:
   * fields:
   * ...this.rank... String
   * ...this.suit... String
   * ...this.value... int
   * ...this.isFaceUp... boolean
   * methods:
   * ...this.flip()... void
   * ...this.isMatch()... boolean
   * ...this.draw()... WorldImage
   * ...this.isRemoved()... boolean
   * ...this.setRemoved(boolean)... void
   * methods for fields:
   * 
   */

  // EFFECT: changes this card to face the opposite way
  void flip() {
    this.isFaceUp = !this.isFaceUp; // either up or down
  }

  // checks if this card matches the given card
  boolean isMatch(Card other, int mode) {
    if (mode == 1) { //easy
      return this.value == other.value;
    }
    if (mode == 2) { //hard
      return ((this.value == other.value) // same number
          && (((this.suit.equals("♣") && other.suit.equals("♠")) || this.suit.equals("♠") && other.suit.equals("♣"))
              || ((this.suit.equals("♦") && other.suit.equals("♥")) || this.suit.equals("♥") && other.suit.equals("♦"))));
    }
    else {
      return false;
    }
  }

  // draws this card on World
  WorldImage draw(int cardWidth, int cardHeight) {
    // need to check if card is in standard deck (removed if found)
    // only face if face up
    if (this.isFaceUp) {
      if (this.suit.equals("♣") || this.suit.equals("♠")) {
        return new TextImage(this.rank + this.suit, cardHeight / 2, Color.BLACK);
      }
      else {
        return new TextImage(this.rank + this.suit, cardHeight / 2, Color.RED);
      }
    }
    // draws back of card is face down
    else {
      return new RectangleImage(cardWidth, cardHeight, OutlineMode.SOLID, Color.GRAY);
    }
  }

  // checks if this card is removed
  public boolean isRemoved() {
    return this.removed;
  }

  //EFFECT: sets the removed status of this card (wont draw)
  public void setRemoved(boolean r) {
    this.removed = r;
  }

}

//represents the game Concentration 
class Concentration extends World {
  ArrayList<Card> standardDeck = new ArrayList<>(); // composed of 52 cards (initially setup)
  ArrayList<ArrayList<Card>> board = new ArrayList<>(); // 2D grid (what gets edited)
  ArrayList<Card> faceUpCards = new ArrayList<>();
  Random rand;
  int score;
  int flips;
  int sceneWidth;
  boolean checkMatch;

  // extra credit:
  int time;
  int mode; // 0, 1, 2

  // main constructor
  Concentration(int sceneWidth) {
    //for standardDeck:
    setupDeck(); // unshuffled
    this.rand = new Random();
    this.shuffle(); // shuffles and sets up deck
    this.deal(); // deals deck (sets up board)
    this.score = 26;
    this.flips = 0;
    this.sceneWidth = sceneWidth;
    this.checkMatch = false; // default

    // extra:
    this.time = 15;
    this.mode = 0; //0 is choosing screen 
  }

  // constructor for testing (seeded rand)
  Concentration(Random random) {
    this.standardDeck = new ArrayList<>(); // unshuffled
    this.board = new ArrayList<>();
    this.rand = random;
  }
  
  /*template:
   * fields:
   * ...this.board... ArrayList<Card>
   * ...this.standardDeck... ArrayList<Card>
   * ...this.score... int
   * ...this.flips... int
   * ...this.rand... Random
   * ...this.sceneWidth... int 
   * ...this.time... int
   * ...this.mode... boolean
   * methods:
   * ...this.setupDeck()... void
   * ...this.shuffle()... void
   * ...this.deal()... void
   * ...this.onMouseClick()... void
   * ...this.checkMatch()... void
   * ...this.findRowOrCol(int, int, int, int, int)... int 
   * ...this.onTick()... void
   * ...this.checkMatch()... void
   * ...this.onKeyEvent()... void
   * ...this.makeScene()... WorldScene 
   * methods for fields:
   * ...rand.nextInt(int)...int
   * ...standardDeck.size()... int
   * ...standardDeck.get(int)... Card
   * ...standardDeck.set(int, Card)... ArrayList<Card>
   * ...board.add(ArrayList<Card>)... ArrayList<Card>
   * ...board.get(int)... Card
   * ...board.size()... int 
   */

  // EFFECT: initializes the deck for this Concentration game (unshuffled)
  public void setupDeck() {
    ArrayList<String> suits = new ArrayList<>(Arrays.asList("♣", "♦", "♥", "♠"));
    ArrayList<String> ranks = new ArrayList<>(
        Arrays.asList("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", 
            "J", "Q", "K"));

    for (String s : suits) { // nested for loops (ranks for every suit)
      for (int i = 0; i < ranks.size(); i++) {
        standardDeck.add(new Card(ranks.get(i), s, i + 1));
      }
    }
  }

  // EFFECT: shuffles deck for this Concentration game
  public void shuffle() {
    for (int i = 0; i < standardDeck.size(); i++) {
      int randomIndex = this.rand.nextInt(standardDeck.size());
      Card temp = standardDeck.get(i);
      standardDeck.set(i, standardDeck.get(randomIndex));
      standardDeck.set(randomIndex, temp);
    }
  }

  // EFFECT: resets a new board for this Concentration game (already shuffled)
  public void deal() {
    this.board.clear(); // resets

    for (int i = 0; i < 4; i++) { // nested loop
      ArrayList<Card> row = new ArrayList<>();

      for (int j = 0; j < 13; j++) {
        row.add(standardDeck.get(i * 13 + j));
      }
      board.add(row);
    }
  }

  // EFFECT: knows when the mouse clicks a certain card to flip it and check for a
  // match in this Concentration game
  public void onMouseClicked(Posn pos) {

    // dimensions:

    int sceneWidth = this.sceneWidth;
    int sceneHeight = sceneWidth;
    int cardArea = sceneWidth * 2;
    int cardWidth = cardArea / 40; // bottom length of card
    int cardHeight = cardArea / 30; // side length of card
    int cardStartingLocX = sceneWidth / 15; // cards beginning being drawn at this point
    int cardIncreaseX = (sceneWidth - (cardStartingLocX * 2) - (cardWidth * 13)) / 3;
    int cardIncreaseY = cardHeight + (cardHeight / 2);
    int wordsStartingLocY = (sceneHeight / 12) + cardHeight;
    int cardStartingLocY = wordsStartingLocY * 2;

    int easyModeBoxX = sceneWidth / 2; // middle
    int easyModeBoxY = wordsStartingLocY * 3; // middle

    int hardModeBoxX = sceneWidth / 2; // middle
    int hardModeBoxY = wordsStartingLocY * 5; // middle

    int modeBoxWidth = cardWidth * 4;
    int modeBoxHeight = cardWidth * 2;

    // for choosing a mode:
    if ((mode == 0) && (pos.x >= (easyModeBoxX - (modeBoxWidth / 2))
        && (pos.x <= (easyModeBoxX + (modeBoxWidth / 2)))
        && pos.y >= (easyModeBoxY - (modeBoxHeight / 2))
        && pos.y <= (easyModeBoxY + (modeBoxHeight / 2)))) {
      this.mode = 1;
    }
    if ((mode == 0) && (pos.x >= (hardModeBoxX - (modeBoxWidth / 2))
        && (pos.x <= (hardModeBoxX + (modeBoxWidth / 2)))
        && pos.y >= (hardModeBoxY - (modeBoxHeight / 2))
        && pos.y <= (hardModeBoxY + (modeBoxHeight / 2)))) {
      this.mode = 2;
    }

    // initializing rows (4) and columns (13):
    int rowSelected = findRowOrCol(pos.y, 4, cardStartingLocY, cardIncreaseY, cardHeight);
    int colSelected = findRowOrCol(pos.x, 13, cardStartingLocX, cardIncreaseX, cardWidth);

    // for game:
    // checking that calculated row and col are within bounds
    if ((mode != 0) && rowSelected >= 0 && rowSelected < 4 && colSelected >= 0
        && colSelected < 13) {

      // calculating exact top left position of the targeted card (check click bounds)
      int cardX = cardStartingLocX + (colSelected * cardIncreaseX);
      int cardY = cardStartingLocY + (rowSelected * cardIncreaseY);

      if ((pos.x >= (cardX - cardWidth / 2)) && (pos.x <= (cardX + cardWidth / 2))
          && (pos.y >= (cardY - cardHeight / 2)) && (pos.y <= (cardY + cardHeight / 2))) {
        // System.out.println("card was clicked");
        Card selectedC = this.board.get(rowSelected).get(colSelected);
        if (!selectedC.isFaceUp && !selectedC.isRemoved()) {
          selectedC.flip(); // flips card!
          // System.out.println("card was flipped");
          faceUpCards.add(selectedC);
          this.flips++; // max 2

          // checks if two cards are face up
          if (faceUpCards.size() >= 2) { // two at a time
            // System.out.println("size" + faceUpCards.size());
            checkMatch = true; // Delay the check to the next tick
          }
        }
      }
    }

  }
  
  // ABSTRACTION: finds what the row or column of where the player clicked in this
  // Concentration game
  public int findRowOrCol(int pos, int num, int a, int b, int c) {
    for (int i = 0; i < num; i++) {
      int start = (a + (b * i)) - (c / 2); // starts
      int end = (a + (b * i)) + (c / 2); // ends
      if ((pos >= start) && (pos <= end)) {
        return i;
      }
    }
    return -1; // shouldnt happen aka error

  }

  // EFFECT: delayed check to see if there are two cards face-up in this
  // Concentration game
  public void onTick() {
    // every tick check:
    if (checkMatch && (faceUpCards.size() >= 2)) {
      checkMatch();
      checkMatch = false; // resets after checking
    }
    //when clock runs out:
    if (this.time == 0) {
      shuffle();
      deal();
      this.time = 15;
    }
    //every tick do:
    if (mode != 0) {
      this.time = time - 1;
    }
  }

  // EFFECT: compares the two flipped cards to see if they are a match in this
  // Concentration game
  private void checkMatch() {
    Card card1 = faceUpCards.get(0);
    Card card2 = faceUpCards.get(1);

    if (card1.isMatch(card2, this.mode)) {
      // cards match - deduct a point and "remove" the cards
      this.score = this.score - 1;
      card1.setRemoved(true);
      card2.setRemoved(true);
    }
    int index = 0;
    while (index < faceUpCards.size()) {
      Card card = faceUpCards.get(index);
      card.flip();
      index = index + 1;
    }
    // rests array
    faceUpCards.clear();

  }

  // EFFECT: resets this Concentration game
  public void onKeyEvent(String key) {
    if (key.equals("r")) {
      this.standardDeck = new ArrayList<>(); // reset
      this.setupDeck();
      this.shuffle();
      this.deal();
      this.score = 26;
      this.flips = 0;
    }

    if (key.equals("h")) {
      this.standardDeck = new ArrayList<>(); // reset
      this.setupDeck();
      this.shuffle();
      this.deal();
      this.score = 26;
      this.flips = 0;
      this.mode = 0;
    }
  }

  // draws this Concentration game
  // need to have 4 rows of 13 cards
  public WorldScene makeScene() {

    // dimensions: allows screen to be different sizes

    int sceneWidth = this.sceneWidth;
    int sceneHeight = sceneWidth;
    int cardArea = sceneWidth * 2;
    int cardWidth = cardArea / 40;
    int cardHeight = cardArea / 30;
    int cardStartingLocX = sceneWidth / 15;
    int cardIncreaseX = (sceneWidth - (cardStartingLocX * 2) - (cardWidth * 13)) / 3;
    int cardIncreaseY = cardHeight + (cardHeight / 2);
    int wordsStartingLocY = (sceneHeight / 12) + cardHeight;
    int cardStartingLocY = wordsStartingLocY * 2;
    int scoreLoc = sceneHeight - 50;

    // scene building:

    WorldScene scene = this.getEmptyScene();
    
    // first screen
    if (mode == 0) {
      scene.placeImageXY(new TextImage("Welcome to Concentration", cardHeight, Color.BLACK), 
          sceneWidth / 2, sceneHeight / 12);
      scene.placeImageXY(new TextImage("Choose your mode!",
          cardWidth, Color.BLACK)
          , sceneWidth / 2, wordsStartingLocY);
      //easy:
      scene.placeImageXY(new TextImage("Match all pairs of the same value:",
          cardWidth / 2, Color.BLACK)
          , sceneWidth / 2, (wordsStartingLocY * 3) - (cardWidth * 2));
      scene.placeImageXY(new RectangleImage(
          cardWidth * 4, cardWidth * 2, OutlineMode.SOLID, Color.GREEN)
          , sceneWidth / 2, wordsStartingLocY * 3);
      scene.placeImageXY(new TextImage("EASY",
          cardWidth, Color.BLACK)
          , sceneWidth / 2, wordsStartingLocY * 3);
      // hard:
      scene.placeImageXY(new TextImage("Match all pairs of the same value AND same color:",
          cardWidth / 2, Color.BLACK)
          , sceneWidth / 2, (wordsStartingLocY * 5) - (cardWidth * 2));
      scene.placeImageXY(new RectangleImage(
          cardWidth * 4, cardWidth * 2, OutlineMode.SOLID, Color.RED)
          , sceneWidth / 2, wordsStartingLocY * 5);
      scene.placeImageXY(new TextImage("HARD",
          cardWidth, Color.BLACK)
          , sceneWidth / 2, wordsStartingLocY * 5);
    }
    
    // easy and hard mode:
    if (mode != 0) {
      TextImage name = new TextImage("Welcome to Concentration!", cardHeight, Color.BLACK);
      
      if (mode == 1) {
        TextImage modeText = new TextImage("(EASY)", cardWidth / 2, Color.BLACK);
        scene.placeImageXY(modeText, sceneWidth / 2, wordsStartingLocY);
      }
      
      else {
        TextImage modeText = new TextImage("(HARD)", cardWidth / 2, Color.BLACK);
        scene.placeImageXY(modeText, sceneWidth / 2, wordsStartingLocY);
      }
      
      TextImage start = new TextImage("Cards will shuffle every 15 seconds. Match ALL pairs to win!",
          cardWidth / 2, Color.BLACK);
      scene.placeImageXY(name, sceneWidth / 2, sceneHeight / 12);
      scene.placeImageXY(start, sceneWidth / 2, wordsStartingLocY + cardHeight);

      for (int i = 0; i < board.size(); i++) {
        for (int j = 0; j < board.get(i).size(); j++) {
          Card card = board.get(i).get(j);
          // Only display cards that haven't been removed
          if (!card.isRemoved()) {
            RectangleImage outline = new RectangleImage(cardWidth + 10, cardHeight + 10,
                OutlineMode.OUTLINE, Color.BLACK);
            scene.placeImageXY(outline, cardIncreaseX * j + cardStartingLocX,
                cardIncreaseY * i + cardStartingLocY);
            scene.placeImageXY(card.draw(cardWidth, cardHeight), cardIncreaseX * j + cardStartingLocX,
                cardIncreaseY * i + cardStartingLocY);
          }
        }
      }

      //time:
      if (score != 0) {
        scene.placeImageXY(new TextImage("Time: " + this.time, cardWidth, Color.BLACK),
            sceneWidth / 2, scoreLoc - cardWidth);
      }
      
      // score:
      scene.placeImageXY(new TextImage("Matches Left: " + this.score, cardWidth / 2, Color.BLACK),
          sceneWidth / 2, scoreLoc);
      scene.placeImageXY(new TextImage("Press r to reset. Press h to go back to homepage.", cardWidth / 3, Color.BLACK),
          sceneWidth / 2, scoreLoc + 20);
      
      // winner:
      if (score == 0) {
        scene.placeImageXY(new RectangleImage(sceneWidth, sceneWidth, OutlineMode.SOLID, Color.GREEN), sceneWidth / 2,
            sceneWidth / 2);
        scene.placeImageXY(new TextImage("YOU WON!!!", cardHeight, Color.BLACK), sceneWidth / 2,
            (sceneHeight / 2));
      }   
    }
    return scene;
  }
}






